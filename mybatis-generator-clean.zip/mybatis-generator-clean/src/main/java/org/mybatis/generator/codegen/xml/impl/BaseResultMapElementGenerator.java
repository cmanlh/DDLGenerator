/**
 * 
 */
package org.mybatis.generator.codegen.xml.impl;

import java.util.ArrayList;
import java.util.List;

import org.mybatis.generator.codegen.xml.TableElementGenerator;
import org.mybatis.generator.codegen.xml.constant.XMLAttribute;
import org.mybatis.generator.codegen.xml.constant.XMLTag;
import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.dom.xml.Attribute;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public class BaseResultMapElementGenerator implements TableElementGenerator {

  public XmlElement getElement(Table table) {
    XmlElement element = new XmlElement(XMLTag.RESULT_MAP.getName());


    element.addAttribute(new Attribute(XMLAttribute.ID.getName(), table.getBaseResultMap().getId()));
    element.addAttribute(new Attribute(XMLAttribute.TYPE.getName(), table.getBaseResultMap().getType()));

    AssociationElementGenerator associationGenerator = new AssociationElementGenerator();
    CollectionElementGenerator collectionGenerator = new CollectionElementGenerator();
    ResultElementGenerator resultGenerator = new ResultElementGenerator();

    List<Column> resultColumnList = new ArrayList<Column>();
    List<Column> associationColumnList = new ArrayList<Column>();
    List<Column> collectionColumnList = new ArrayList<Column>();
    for (Column column : table.getColumnList()) {
      switch (column.getResultType()) {
        case ASSOCIATION:
          associationColumnList.add(column);
          break;
        case COLLECTION:
          collectionColumnList.add(column);
          break;
        case RESULT:
          resultColumnList.add(column);
          break;
        default:
          ;
      }
    }

    for (Column column : resultColumnList) {
      element.addElement(resultGenerator.getElement(column));
    }

    for (Column column : associationColumnList) {
      element.addElement(associationGenerator.getElement(column));
    }

    for (Column column : collectionColumnList) {
      element.addElement(collectionGenerator.getElement(column));
    }

    return element;
  }
}
