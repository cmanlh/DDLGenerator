package org.mybatis.generator.db.constant;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.mybatis.generator.db.bean.JDBCType;

public class BaseJDBCTypeMapping {
  private static Map<Integer, JDBCType> typeMap = new HashMap<Integer, JDBCType>();

  static final int NVARCHAR = -9;
  static final int NCHAR = -15;
  static final int NCLOB = 2011;

  static {
    typeMap.put(Types.ARRAY, new JDBCType(Types.ARRAY, "ARRAY", Object.class.getName(), null));
    typeMap.put(Types.BIGINT, new JDBCType(Types.BIGINT, "BIGINT", Long.class.getName(), null));
    typeMap.put(Types.BINARY, new JDBCType(Types.BINARY, "BINARY", "byte[]", null));
    typeMap.put(Types.BIT, new JDBCType(Types.BIT, "BIT", Boolean.class.getName(), null));
    typeMap.put(Types.BLOB, new JDBCType(Types.BLOB, "BLOB", "byte[]", null));
    typeMap.put(Types.BOOLEAN, new JDBCType(Types.BOOLEAN, "BOOLEAN", Boolean.class.getName(), null));
    typeMap.put(Types.CHAR, new JDBCType(Types.CHAR, "CHAR", String.class.getName(), null));
    typeMap.put(Types.CLOB, new JDBCType(Types.CLOB, "CLOB", String.class.getName(), null));
    typeMap.put(Types.DATALINK, new JDBCType(Types.DATALINK, "DATALINK", Object.class.getName(), null));
    typeMap.put(Types.DATE, new JDBCType(Types.DATE, "DATE", Date.class.getName(), null));
    typeMap.put(Types.DISTINCT, new JDBCType(Types.DISTINCT, "DISTINCT", Object.class.getName(), null));
    typeMap.put(Types.DOUBLE, new JDBCType(Types.DOUBLE, "DOUBLE", Double.class.getName(), null));
    typeMap.put(Types.FLOAT, new JDBCType(Types.FLOAT, "FLOAT", Double.class.getName(), null));
    typeMap.put(Types.INTEGER, new JDBCType(Types.INTEGER, "INTEGER", Integer.class.getName(), null));
    typeMap.put(Types.JAVA_OBJECT, new JDBCType(Types.JAVA_OBJECT, "JAVA_OBJECT", Object.class.getName(), null));
    typeMap.put(Types.LONGVARBINARY, new JDBCType(Types.LONGVARBINARY, "LONGVARBINARY", "byte[]", null));
    typeMap.put(Types.LONGVARCHAR, new JDBCType(Types.LONGVARCHAR, "LONGVARCHAR", String.class.getName(), null));
    typeMap.put(NCHAR, new JDBCType(NCHAR, "NCHAR", String.class.getName(), null));
    typeMap.put(NCLOB, new JDBCType(NCLOB, "NCLOB", String.class.getName(), null));
    typeMap.put(NVARCHAR, new JDBCType(NVARCHAR, "NVARCHAR", String.class.getName(), null));
    typeMap.put(Types.NULL, new JDBCType(Types.NULL, "NULL", Object.class.getName(), null));
    typeMap.put(Types.OTHER, new JDBCType(Types.OTHER, "OTHER", Object.class.getName(), null));
    typeMap.put(Types.REAL, new JDBCType(Types.REAL, "REAL", Float.class.getName(), null));
    typeMap.put(Types.REF, new JDBCType(Types.REF, "REF", Object.class.getName(), null));
    typeMap.put(Types.SMALLINT, new JDBCType(Types.SMALLINT, "SMALLINT", Short.class.getName(), null));
    typeMap.put(Types.STRUCT, new JDBCType(Types.STRUCT, "STRUCT", Object.class.getName(), null));
    typeMap.put(Types.TIME, new JDBCType(Types.TIME, "TIME", Date.class.getName(), null));
    typeMap.put(Types.TIMESTAMP, new JDBCType(Types.TIMESTAMP, "TIMESTAMP", Date.class.getName(), null));
    typeMap.put(Types.TINYINT, new JDBCType(Types.TINYINT, "TINYINT", Byte.class.getName(), null));
    typeMap.put(Types.VARBINARY, new JDBCType(Types.VARBINARY, "VARBINARY", "byte[]", null));
    typeMap.put(Types.VARCHAR, new JDBCType(Types.VARCHAR, "VARCHAR", String.class.getName(), null));
    typeMap.put(Types.DECIMAL, new JDBCType(Types.ARRAY, "DECIMAL", BigDecimal.class.getName(), null));
    typeMap.put(Types.NUMERIC, new JDBCType(Types.NUMERIC, "NUMERIC", BigDecimal.class.getName(), null));
  }

  public static JDBCType getJdbcType(int jdbcType) {
    return typeMap.get(jdbcType);
  }
}
