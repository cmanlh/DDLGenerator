package org.mybatis.generator.db.util;

import org.mybatis.generator.db.bean.JDBCConnectionConfiguration;

public class DBInfoUtil {
  public static String getDBType(JDBCConnectionConfiguration config) {
    assert (null != config && null != config.getConnectionURL() && config.getConnectionURL().length() > 0);

    String[] metadatas = config.getConnectionURL().split(":");

    return metadatas[2];
  }
}
