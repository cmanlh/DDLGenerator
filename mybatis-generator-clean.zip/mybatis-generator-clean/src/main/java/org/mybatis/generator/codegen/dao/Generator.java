/**
 * 
 */
package org.mybatis.generator.codegen.dao;

import org.mybatis.generator.db.bean.Table;

/**
 * @author luhong
 *
 */
public interface Generator {

  public String getContent(Table table);
}
