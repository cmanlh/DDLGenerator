/**
 * 
 */
package org.mybatis.generator.codegen.xml.impl;

import org.mybatis.generator.codegen.xml.TableElementGenerator;
import org.mybatis.generator.codegen.xml.constant.XMLAttribute;
import org.mybatis.generator.codegen.xml.constant.XMLTag;
import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.dom.xml.Attribute;
import org.mybatis.generator.dom.xml.TextElement;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public class SelectGetElementGenerator implements TableElementGenerator {

  public XmlElement getElement(Table table) {
    XmlElement element = new XmlElement(XMLTag.SELECT.getName());

    element.addAttribute(new Attribute(XMLAttribute.ID.getName(), "get"));
    element.addAttribute(new Attribute(XMLAttribute.RESULT_MAP.getName(), table.getBaseResultMap().getId()));

    TextElement selectElement = new TextElement("select");
    element.addElement(selectElement);

    XmlElement includeElement = new XmlElement(XMLTag.INCLUDE.getName());
    includeElement.addAttribute(new Attribute(XMLAttribute.REF_ID.getName(), table.getBaseColumnListId()));
    element.addElement(includeElement);

    StringBuilder sb = new StringBuilder();
    sb.append("from ").append(table.getName()).append(" where ").append(table.getUniqueKey().getActualColumnName()).append(" = #{id}");
    TextElement fromElement = new TextElement(sb.toString());
    element.addElement(fromElement);

    return element;
  }
}
