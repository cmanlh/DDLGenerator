/**
 * 
 */
package org.mybatis.generator.codegen.model;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.db.bean.JDBCType;
import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.dom.util.OutputUtilities;

/**
 * @author luhong
 *
 */
public class PBDefinitionGenerator implements Generator {
  private String _package;

  private List<String> options;

  private List<String> imports;

  public PBDefinitionGenerator(String _package, List<String> options, List<String> imports) {
    this._package = _package;
    this.options = options;
    this.imports = imports;
  }

  public String getHead() {
    StringBuilder sb = new StringBuilder();

    sb.append("package ").append(_package).append(";");
    OutputUtilities.newLine(sb);

    OutputUtilities.newLine(sb);

    for (String option : options) {
      sb.append("option ").append(option).append(";");
      OutputUtilities.newLine(sb);
    }

    OutputUtilities.newLine(sb);

    for (String _import : imports) {
      sb.append("import ").append(_import).append(";");
      OutputUtilities.newLine(sb);
    }

    OutputUtilities.newLine(sb);

    return sb.toString();

  }

  public String getContent(Table table) {
    StringBuilder sb = new StringBuilder();

    List<Column> columnList = table.getColumnList();

    List<Column> requiredColList = new ArrayList<Column>();
    List<Column> optionalColList = new ArrayList<Column>();

    for (Column column : columnList) {
      if (column.isNullable()) {
        optionalColList.add(column);
      } else {
        requiredColList.add(column);
      }
    }

    sb.append("message ").append(table.getName()).append("PB {");
    OutputUtilities.newLine(sb);

    int idx = 1;
    for (Column column : requiredColList) {
      OutputUtilities.javaIndent(sb, 1);
      sb.append("required ").append(getPBType(column)).append(" ").append(column.getActualColumnName()).append(" = ").append(idx).append(";");
      OutputUtilities.newLine(sb);

      idx++;
    }

    idx = 101;
    for (Column column : optionalColList) {
      OutputUtilities.javaIndent(sb, 1);
      sb.append("optional ").append(getPBType(column)).append(" ").append(column.getActualColumnName()).append(" = ").append(idx).append(";");
      OutputUtilities.newLine(sb);

      idx++;
    }

    sb.append("}");

    return sb.toString();
  }

  private static String getPBType(Column column) {
    JDBCType jdbcType = column.getTypeInfo();
    switch (jdbcType.getType()) {
      case Types.BIT:
        return "bool";
      case Types.DECIMAL:
        return "double";
      case Types.INTEGER:
        String typeHandler = jdbcType.getTypeHandler();
        if (null != typeHandler) {
          return typeHandler.substring(typeHandler.lastIndexOf(".") + 1, typeHandler.lastIndexOf("TypeHandler"));
        } else {
          return "int32";
        }
      case Types.TIMESTAMP:
        return "int64";
      default:
        return "string";
    }
  }
}
