/**
 * 
 */
package org.mybatis.generator.codegen.xml;

import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public interface TableElementGenerator {

  public XmlElement getElement(Table table);

}
