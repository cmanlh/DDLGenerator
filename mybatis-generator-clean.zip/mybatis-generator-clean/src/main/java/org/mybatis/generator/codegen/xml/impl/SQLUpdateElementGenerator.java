/**
 * 
 */
package org.mybatis.generator.codegen.xml.impl;

import org.mybatis.generator.codegen.xml.TableElementGenerator;
import org.mybatis.generator.codegen.xml.constant.XMLAttribute;
import org.mybatis.generator.codegen.xml.constant.XMLTag;
import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.dom.xml.Attribute;
import org.mybatis.generator.dom.xml.TextElement;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public class SQLUpdateElementGenerator implements TableElementGenerator {

  public XmlElement getElement(Table table) {
    XmlElement element = new XmlElement(XMLTag.SQL.getName());

    element.addAttribute(new Attribute(XMLAttribute.ID.getName(), "updateSQL"));

    StringBuilder sb = new StringBuilder();
    sb.append("update ").append(table.getName()).append(" set ");

    int tmpSize = sb.length();
    for (Column column : table.getColumnList()) {
      sb.append(column.getActualColumnName()).append(" = ");
      sb.append("#{").append(column.getActualColumnName()).append(", jdbcType=").append(column.getTypeInfo().getName());
      if (null != column.getTypeInfo().getTypeHandler()) {
        sb.append(", typeHandler=").append(column.getTypeInfo().getTypeHandler());
      }
      sb.append("},");
    }

    if (sb.length() > tmpSize) {
      element.addElement((new TextElement(sb.substring(0, sb.length() - 1))));
    }

    return element;
  }
}
