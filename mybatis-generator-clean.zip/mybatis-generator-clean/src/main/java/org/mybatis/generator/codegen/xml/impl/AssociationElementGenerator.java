/**
 * 
 */
package org.mybatis.generator.codegen.xml.impl;

import org.mybatis.generator.codegen.xml.ColumnElementGenerator;
import org.mybatis.generator.codegen.xml.constant.XMLAttribute;
import org.mybatis.generator.codegen.xml.constant.XMLTag;
import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.dom.xml.Attribute;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public class AssociationElementGenerator implements ColumnElementGenerator {

  public XmlElement getElement(Column column) {
    XmlElement element = new XmlElement(XMLTag.ASSOCIATION.getName());

    element.addAttribute(new Attribute(XMLAttribute.COLUMN.getName(), column.getActualColumnName()));
    element.addAttribute(new Attribute(XMLAttribute.PROPERTY.getName(), column.getJavaProperty()));

    element.addAttribute(new Attribute(XMLAttribute.JAVA_TYPE.getName(), column.getAssociation().getJavaType()));
    element.addAttribute(new Attribute(XMLAttribute.SELECT.getName(), column.getAssociation().getSelect()));

    return element;
  }
}
