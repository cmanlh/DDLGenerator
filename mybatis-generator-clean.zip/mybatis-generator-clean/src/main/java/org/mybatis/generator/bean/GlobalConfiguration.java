/**
 * 
 */
package org.mybatis.generator.bean;

import java.io.Serializable;
import java.util.Map;

import org.mybatis.generator.db.bean.JDBCType;

/**
 * @author luhong
 *
 */
public class GlobalConfiguration implements Serializable {

  private static final long serialVersionUID = -5739400077596825579L;

  private Map<Integer, JDBCType> jdbcTypeOverwrite;

  private Map<String, TableConfiguration> tableOverwrite;

  private String xmlMapperFolder;

  private String daoFolder;

  public Map<Integer, JDBCType> getJdbcTypeOverwrite() {
    return jdbcTypeOverwrite;
  }

  public void setJdbcTypeOverwrite(Map<Integer, JDBCType> jdbcTypeOverwrite) {
    this.jdbcTypeOverwrite = jdbcTypeOverwrite;
  }

  public Map<String, TableConfiguration> getTableOverwrite() {
    return tableOverwrite;
  }

  public void setTableOverwrite(Map<String, TableConfiguration> tableOverwrite) {
    this.tableOverwrite = tableOverwrite;
  }

  public String getXmlMapperFolder() {
    return xmlMapperFolder;
  }

  public void setXmlMapperFolder(String xmlMapperFolder) {
    this.xmlMapperFolder = xmlMapperFolder;
  }

  public String getDaoFolder() {
    return daoFolder;
  }

  public void setDaoFolder(String daoFolder) {
    this.daoFolder = daoFolder;
  }
}
