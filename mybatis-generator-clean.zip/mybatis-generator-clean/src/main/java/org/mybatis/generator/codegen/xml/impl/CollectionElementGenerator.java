/**
 * 
 */
package org.mybatis.generator.codegen.xml.impl;

import org.mybatis.generator.codegen.xml.ColumnElementGenerator;
import org.mybatis.generator.codegen.xml.constant.XMLAttribute;
import org.mybatis.generator.codegen.xml.constant.XMLTag;
import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.dom.xml.Attribute;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public class CollectionElementGenerator implements ColumnElementGenerator {

  public XmlElement getElement(Column column) {
    XmlElement element = new XmlElement(XMLTag.COLLECTION.getName());

    element.addAttribute(new Attribute(XMLAttribute.COLUMN.getName(), column.getActualColumnName()));
    element.addAttribute(new Attribute(XMLAttribute.PROPERTY.getName(), column.getJavaProperty()));

    element.addAttribute(new Attribute(XMLAttribute.OF_TYPE.getName(), column.getCollection().getOfType()));
    element.addAttribute(new Attribute(XMLAttribute.SELECT.getName(), column.getCollection().getSelect()));

    return element;
  }
}
