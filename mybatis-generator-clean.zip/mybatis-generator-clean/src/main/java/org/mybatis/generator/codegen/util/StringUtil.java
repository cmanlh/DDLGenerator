/**
 * 
 */
package org.mybatis.generator.codegen.util;

/**
 * @author luhong
 *
 */
public class StringUtil {
    public static String capitalize(String target) {
        return target.substring(0, 1).toUpperCase() + target.substring(1);
    }
}
