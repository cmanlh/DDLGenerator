package org.mybatis.generator.db.bean;

import java.io.Serializable;
import java.util.List;

import org.mybatis.generator.codegen.xml.bean.ResultMap;

/**
 * 
 * @author luhong
 *
 */
public class Table implements Serializable {

    private static final long serialVersionUID = 361967934065441137L;

    private String name;

    private String namespace;

    private String baseColumnListId = "baseColumnList";

    private ResultMap baseResultMap;

    private ResultMap simpleResultMap;

    private Column uniqueKey;

    private List<Column> primaryKey;

    private String insertParameterType;

    private String updateParameterType;

    private List<Column> columnList;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getBaseColumnListId() {
        return baseColumnListId;
    }

    public void setBaseColumnListId(String baseColumnListId) {
        this.baseColumnListId = baseColumnListId;
    }

    public ResultMap getBaseResultMap() {
        return baseResultMap;
    }

    public void setBaseResultMap(ResultMap baseResultMap) {
        this.baseResultMap = baseResultMap;
    }

    public ResultMap getSimpleResultMap() {
        return simpleResultMap;
    }

    public void setSimpleResultMap(ResultMap simpleResultMap) {
        this.simpleResultMap = simpleResultMap;
    }

    public Column getUniqueKey() {
        return uniqueKey;
    }

    public void setUniqueKey(Column uniqueKey) {
        this.uniqueKey = uniqueKey;
    }

    public String getInsertParameterType() {
        return insertParameterType;
    }

    public void setInsertParameterType(String insertParameterType) {
        this.insertParameterType = insertParameterType;
    }

    public String getUpdateParameterType() {
        return updateParameterType;
    }

    public void setUpdateParameterType(String updateParameterType) {
        this.updateParameterType = updateParameterType;
    }

    public List<Column> getColumnList() {
        return columnList;
    }

    public void setColumnList(List<Column> columnList) {
        this.columnList = columnList;
    }

    public List<Column> getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(List<Column> primaryKey) {
        this.primaryKey = primaryKey;
    }
}
