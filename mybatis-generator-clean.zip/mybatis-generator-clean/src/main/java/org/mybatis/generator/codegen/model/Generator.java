/**
 * 
 */
package org.mybatis.generator.codegen.model;

import org.mybatis.generator.db.bean.Table;

/**
 * @author luhong
 *
 */
public interface Generator {

  public String getContent(Table table);
}
