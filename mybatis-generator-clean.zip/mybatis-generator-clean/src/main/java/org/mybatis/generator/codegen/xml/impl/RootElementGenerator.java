/**
 * 
 */
package org.mybatis.generator.codegen.xml.impl;

import org.mybatis.generator.codegen.xml.TableElementGenerator;
import org.mybatis.generator.codegen.xml.constant.XMLAttribute;
import org.mybatis.generator.codegen.xml.constant.XMLTag;
import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.dom.xml.Attribute;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public class RootElementGenerator implements TableElementGenerator {

  public XmlElement getElement(Table table) {
    XmlElement element = new XmlElement(XMLTag.ROOT.getName());

    String namespace = table.getNamespace();
    if (null == namespace) {
      namespace = table.getName();
    }

    element.addAttribute(new Attribute(XMLAttribute.NAMESPACE.getName(), namespace));

    return element;
  }
}
