/**
 * 
 */
package org.mybatis.generator.codegen.xml.bean;

/**
 * @author luhong
 *
 */
public class ResultMap {

  private String id = "baseResultMap";

  private String type;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }
}
