/**
 * 
 */
package org.mybatis.generator.codegen.dao;

import java.util.TreeSet;

import org.mybatis.generator.db.bean.Table;

/**
 * @author luhong
 *
 */
public class DAOGenerator implements Generator {
  private static final String lineSeparator;

  static {
    String ls = System.getProperty("line.separator");
    if (ls == null) {
      ls = "\n";
    }
    lineSeparator = ls;
  }

  public String getContent(Table table) {
    int inPackage = table.getNamespace().lastIndexOf(".");
    String _package = null, className = null;
    if (inPackage > 0) {
      _package = table.getNamespace().substring(0, inPackage);
      className = table.getNamespace().substring(inPackage + 1);
    } else {
      return "";
    }

    TreeSet<String> importSet = new TreeSet<String>();
    importSet.add(table.getBaseResultMap().getType().replace("$", "."));
    importSet.add(table.getInsertParameterType().replace("$", "."));
    importSet.add(table.getUpdateParameterType().replace("$", "."));

    String dtoClass = table.getBaseResultMap().getType().substring(table.getBaseResultMap().getType().lastIndexOf("$") + 1);
    String insertParamClass = table.getInsertParameterType().substring(table.getInsertParameterType().lastIndexOf("$") + 1);
    String updateParamClass = table.getUpdateParameterType().substring(table.getUpdateParameterType().lastIndexOf("$") + 1);

    StringBuilder sb = new StringBuilder();
    if (null != _package) {
      sb.append("package ").append(_package).append(";").append(lineSeparator);
      sb.append(lineSeparator);
    }
    for (String _import : importSet) {
      sb.append("import ").append(_import).append(";").append(lineSeparator);
    }
    sb.append(lineSeparator);
    sb.append("public interface ").append(className).append(" {").append(lineSeparator);
    sb.append(lineSeparator);
    sb.append("  public ").append(dtoClass).append(" get(String id);").append(lineSeparator);
    sb.append(lineSeparator);
    sb.append("  public int ").append("insert(").append(insertParamClass).append(" param);").append(lineSeparator);
    sb.append(lineSeparator);
    sb.append("  public int ").append("update(").append(updateParamClass).append(" param);").append(lineSeparator);
    sb.append(lineSeparator);
    sb.append("  public int ").append("delete(String id);").append(lineSeparator);
    sb.append(lineSeparator).append("}");

    return sb.toString();
  }
}
