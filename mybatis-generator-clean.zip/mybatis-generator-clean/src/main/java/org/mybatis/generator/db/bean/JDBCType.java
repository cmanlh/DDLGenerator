package org.mybatis.generator.db.bean;

import java.io.Serializable;

/**
 * 
 * @author luhong
 *
 */
public class JDBCType implements Serializable {
  private static final long serialVersionUID = -6659030342868194939L;

  private int type;

  private String name;

  private String javaType;

  private String typeHandler;

  public JDBCType() {

  }

  public JDBCType(int type, String name, String javaType, String typeHandler) {
    this.type = type;
    this.name = name;
    this.javaType = javaType;
    this.typeHandler = typeHandler;
  }

  public int getType() {
    return type;
  }

  public void setType(int type) {
    this.type = type;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getJavaType() {
    return javaType;
  }

  public void setJavaType(String javaType) {
    this.javaType = javaType;
  }

  public String getTypeHandler() {
    return typeHandler;
  }

  public void setTypeHandler(String typeHandler) {
    this.typeHandler = typeHandler;
  }
}
