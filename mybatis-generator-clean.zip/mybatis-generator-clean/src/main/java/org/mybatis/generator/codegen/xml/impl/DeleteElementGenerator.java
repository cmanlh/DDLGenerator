/**
 * 
 */
package org.mybatis.generator.codegen.xml.impl;

import java.util.List;

import org.mybatis.generator.codegen.xml.TableElementGenerator;
import org.mybatis.generator.codegen.xml.constant.XMLAttribute;
import org.mybatis.generator.codegen.xml.constant.XMLTag;
import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.dom.xml.Attribute;
import org.mybatis.generator.dom.xml.TextElement;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public class DeleteElementGenerator implements TableElementGenerator {

    public XmlElement getElement(Table table) {
        XmlElement element = new XmlElement(XMLTag.DELETE.getName());

        element.addAttribute(new Attribute(XMLAttribute.ID.getName(), "delete"));

        StringBuilder sb = new StringBuilder();
        if (null != table.getUniqueKey()) {
            sb.append("delete from ").append(table.getName()).append(" where ").append(table.getUniqueKey().getActualColumnName()).append(" = #{id}");
        } else {
            List<Column> primaryKey = table.getPrimaryKey();
            if (null != primaryKey && primaryKey.size() > 0) {
                sb.append("delete from ").append(table.getName()).append(" where ");
                for (Column column : primaryKey) {
                    sb.append(column.getActualColumnName()).append(" = ");
                    sb.append("#{").append(column.getActualColumnName()).append(", jdbcType=").append(column.getTypeInfo().getName());
                    if (null != column.getTypeInfo().getTypeHandler()) {
                        sb.append(", typeHandler=").append(column.getTypeInfo().getTypeHandler());
                    }
                    sb.append("} AND ");
                }
                sb = sb.replace(sb.length() - 5, sb.length(), "");
            } else {
                throw new RuntimeException("Should not delete one record without a primary key.");
            }
        }
        TextElement fromElement = new TextElement(sb.toString());
        element.addElement(fromElement);

        return element;
    }
}
