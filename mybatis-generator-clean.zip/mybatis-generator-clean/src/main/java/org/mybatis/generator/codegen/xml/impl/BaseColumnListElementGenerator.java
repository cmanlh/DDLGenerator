/**
 * 
 */
package org.mybatis.generator.codegen.xml.impl;

import org.mybatis.generator.codegen.xml.TableElementGenerator;
import org.mybatis.generator.codegen.xml.constant.XMLAttribute;
import org.mybatis.generator.codegen.xml.constant.XMLTag;
import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.dom.xml.Attribute;
import org.mybatis.generator.dom.xml.TextElement;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public class BaseColumnListElementGenerator implements TableElementGenerator {

  public XmlElement getElement(Table table) {
    XmlElement element = new XmlElement(XMLTag.SQL.getName());

    element.addAttribute(new Attribute(XMLAttribute.ID.getName(), table.getBaseColumnListId()));

    StringBuilder sb = new StringBuilder();
    for (Column column : table.getColumnList()) {
      sb.append(column.getActualColumnName()).append(",");
    }

    if (sb.length() > 0) {
      element.addElement((new TextElement(sb.substring(0, sb.length() - 1))));
    }

    return element;
  }
}
