/**
 * 
 */
package org.mybatis.generator.bean;

import java.io.Serializable;
import java.util.Map;

import org.mybatis.generator.codegen.xml.bean.ResultMap;
import org.mybatis.generator.db.bean.Column;

/**
 * @author luhong
 *
 */
public class TableConfiguration implements Serializable {

  private static final long serialVersionUID = -2516991013078295422L;

  private String name;

  private String namespace;

  private String baseColumnListId;

  private ResultMap baseResultMap;

  private ResultMap simpleResultMap;

  private String uniqueColumn;

  private String insertParameterType;

  private String updateParameterType;

  private Map<String, Column> columnOverWrite;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getNamespace() {
    return namespace;
  }

  public void setNamespace(String namespace) {
    this.namespace = namespace;
  }

  public String getBaseColumnListId() {
    return baseColumnListId;
  }

  public void setBaseColumnListId(String baseColumnListId) {
    this.baseColumnListId = baseColumnListId;
  }

  public ResultMap getBaseResultMap() {
    return baseResultMap;
  }

  public void setBaseResultMap(ResultMap baseResultMap) {
    this.baseResultMap = baseResultMap;
  }

  public ResultMap getSimpleResultMap() {
    return simpleResultMap;
  }

  public void setSimpleResultMap(ResultMap simpleResultMap) {
    this.simpleResultMap = simpleResultMap;
  }

  public String getUniqueColumn() {
    return uniqueColumn;
  }

  public void setUniqueColumn(String uniqueColumn) {
    this.uniqueColumn = uniqueColumn;
  }

  public String getInsertParameterType() {
    return insertParameterType;
  }

  public void setInsertParameterType(String insertParameterType) {
    this.insertParameterType = insertParameterType;
  }

  public String getUpdateParameterType() {
    return updateParameterType;
  }

  public void setUpdateParameterType(String updateParameterType) {
    this.updateParameterType = updateParameterType;
  }

  public Map<String, Column> getColumnOverWrite() {
    return columnOverWrite;
  }

  public void setColumnOverWrite(Map<String, Column> columnOverWrite) {
    this.columnOverWrite = columnOverWrite;
  }


}
