/**
 * 
 */
package org.mybatis.generator.codegen.xml;

import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public interface ColumnElementGenerator {

  public XmlElement getElement(Column column);

}
