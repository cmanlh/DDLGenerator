/**
 * 
 */
package org.mybatis.generator.codegen.xml.impl;

import org.mybatis.generator.codegen.util.StringUtil;
import org.mybatis.generator.codegen.xml.TableElementGenerator;
import org.mybatis.generator.codegen.xml.constant.XMLAttribute;
import org.mybatis.generator.codegen.xml.constant.XMLTag;
import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.dom.xml.Attribute;
import org.mybatis.generator.dom.xml.TextElement;
import org.mybatis.generator.dom.xml.XmlElement;

/**
 * @author luhong
 *
 */
public class SQLDynamicUpdateElementGenerator implements TableElementGenerator {

    public XmlElement getElement(Table table) {
        XmlElement element = new XmlElement(XMLTag.SQL.getName());

        element.addAttribute(new Attribute(XMLAttribute.ID.getName(), "dynamicUpdateSQL"));

        StringBuilder sb = new StringBuilder();
        sb.append("update ").append(table.getName());

        element.addElement(new TextElement(sb.toString()));

        XmlElement trimElement = new XmlElement(XMLTag.TRIM.getName());
        trimElement.addAttribute(new Attribute(XMLAttribute.PREFIX.getName(), "set"));
        trimElement.addAttribute(new Attribute(XMLAttribute.SUFFIX_OVERRIDES.getName(), ","));
        element.addElement(trimElement);

        for (Column column : table.getColumnList()) {
            XmlElement ifElement = new XmlElement(XMLTag.IF.getName());
            ifElement.addAttribute(new Attribute(XMLAttribute.TEST.getName(), "has" + StringUtil.capitalize(column.getActualColumnName())
                    + " == true"));

            StringBuilder setValueText = new StringBuilder();
            setValueText.append(column.getActualColumnName()).append(" = ");
            setValueText.append("#{").append(column.getActualColumnName()).append(", jdbcType=").append(column.getTypeInfo().getName());
            if (null != column.getTypeInfo().getTypeHandler()) {
                setValueText.append(", typeHandler=").append(column.getTypeInfo().getTypeHandler());
            }
            setValueText.append("},");
            TextElement setValue = new TextElement(setValueText.toString());
            ifElement.addElement(setValue);

            trimElement.addElement(ifElement);
        }
        return element;
    }
}
