package org.mybatis.generator.db.constant;

/**
 * 
 * @author luhong
 *
 */
public enum ColumnResultType {
  RESULT, ASSOCIATION, COLLECTION;
}
