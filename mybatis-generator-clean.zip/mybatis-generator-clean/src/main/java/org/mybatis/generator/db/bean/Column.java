/*
 * Copyright 2005 The Apache Software Foundation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.mybatis.generator.db.bean;

import java.io.Serializable;

import org.mybatis.generator.codegen.xml.bean.Association;
import org.mybatis.generator.codegen.xml.bean.Collection;
import org.mybatis.generator.db.constant.ColumnResultType;

/**
 * 
 * @author luhong
 *
 */
public class Column implements Serializable {
  private static final long serialVersionUID = 627718915059108392L;

  private String actualColumnName;

  private JDBCType typeInfo;

  private boolean nullable;

  private int length;

  private int scale;

  private boolean identity;

  private boolean isSequenceColumn;

  private String javaProperty;

  private String remarks;

  private String defaultValue;

  private ColumnResultType resultType = ColumnResultType.RESULT;

  private Association association;

  private Collection collection;

  public String getActualColumnName() {
    return actualColumnName;
  }

  public void setActualColumnName(String actualColumnName) {
    this.actualColumnName = actualColumnName;
  }

  public JDBCType getTypeInfo() {
    return typeInfo;
  }

  public void setTypeInfo(JDBCType typeInfo) {
    this.typeInfo = typeInfo;
  }

  public boolean isNullable() {
    return nullable;
  }

  public void setNullable(boolean nullable) {
    this.nullable = nullable;
  }

  public int getLength() {
    return length;
  }

  public void setLength(int length) {
    this.length = length;
  }

  public int getScale() {
    return scale;
  }

  public void setScale(int scale) {
    this.scale = scale;
  }

  public boolean isIdentity() {
    return identity;
  }

  public void setIdentity(boolean identity) {
    this.identity = identity;
  }

  public boolean isSequenceColumn() {
    return isSequenceColumn;
  }

  public void setSequenceColumn(boolean isSequenceColumn) {
    this.isSequenceColumn = isSequenceColumn;
  }

  public String getJavaProperty() {
    return javaProperty;
  }

  public void setJavaProperty(String javaProperty) {
    this.javaProperty = javaProperty;
  }

  public String getRemarks() {
    return remarks;
  }

  public void setRemarks(String remarks) {
    this.remarks = remarks;
  }

  public String getDefaultValue() {
    return defaultValue;
  }

  public void setDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
  }

  public ColumnResultType getResultType() {
    return resultType;
  }

  public void setResultType(ColumnResultType resultType) {
    this.resultType = resultType;
  }

  public Association getAssociation() {
    return association;
  }

  public void setAssociation(Association association) {
    this.association = association;
  }

  public Collection getCollection() {
    return collection;
  }

  public void setCollection(Collection collection) {
    this.collection = collection;
  }
}
