/**
 * 
 */
package org.mybatis.generator.codegen.xml.constant;

/**
 * @author luhong
 *
 */
public enum XMLTag {
    ROOT("mapper"), RESULT_MAP("resultMap"), RESULT("result"), ASSOCIATION("association"), SQL("sql"), SELECT("select"), INCLUDE("include"), INSERT(
            "insert"), UPDATE("update"), DELETE("delete"), COLLECTION("collection"), SET("set"), IF("if"), TRIM("trim");

    private String name;

    XMLTag(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
