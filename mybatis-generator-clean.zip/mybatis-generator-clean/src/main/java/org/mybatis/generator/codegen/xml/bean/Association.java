/**
 * 
 */
package org.mybatis.generator.codegen.xml.bean;

/**
 * @author luhong
 *
 */
public class Association {

  private String select;

  private String javaType;

  public String getSelect() {
    return select;
  }

  public void setSelect(String select) {
    this.select = select;
  }

  public String getJavaType() {
    return javaType;
  }

  public void setJavaType(String javaType) {
    this.javaType = javaType;
  }

}
