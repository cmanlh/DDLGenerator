/**
 * 
 */
package org.mybatis.generator;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.mybatis.generator.bean.GlobalConfiguration;
import org.mybatis.generator.bean.TableConfiguration;
import org.mybatis.generator.codegen.xml.bean.Association;
import org.mybatis.generator.codegen.xml.bean.Collection;
import org.mybatis.generator.codegen.xml.bean.ResultMap;
import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.db.bean.JDBCType;
import org.mybatis.generator.db.constant.BaseJDBCTypeMapping;
import org.mybatis.generator.db.constant.ColumnResultType;

/**
 * @author luhong
 *
 */
public class MakeConfiguration {
    public static GlobalConfiguration get() {
        GlobalConfiguration globalConfiguration = new GlobalConfiguration();

        globalConfiguration.setDaoFolder("target/dao/");
        globalConfiguration.setXmlMapperFolder("target/mapper/");

        globalConfiguration.setJdbcTypeOverwrite(configTypeOverwrite());
        globalConfiguration.setTableOverwrite(configTableOverwrite());

        return globalConfiguration;
    }

    private static Map<String, TableConfiguration> configTableOverwrite() {
        Map<String, TableConfiguration> tableOverwrite = new HashMap<String, TableConfiguration>();

        String packagePrefix = "com.orientsec.cashmgmt.dao.";
        String typePrefix = "com.orientsec.cashmgmt.pb.CashmgmtDTOPB$";
        String insertTypePrefix = "com.orientsec.cashmgmt.pb.CashmgmtBusinessPB$";
        Column column = null;
        JDBCType jdbcType = null;
        Map<String, Column> columnOverWrite = null;
        Association association = null;
        Collection collection = null;

        TableConfiguration deparment = new TableConfiguration();
        deparment.setName("DepartmentInfo");
        deparment.setBaseColumnListId("baseColumnList");
        ResultMap baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + deparment.getName() + "DTOPB");
        deparment.setInsertParameterType(insertTypePrefix + deparment.getName() + "PB");
        deparment.setBaseResultMap(baseResult);
        deparment.setNamespace(packagePrefix + deparment.getName() + "Mapper");
        deparment.setUniqueColumn("departmentId");
        deparment.setUpdateParameterType(deparment.getInsertParameterType());
        tableOverwrite.put(deparment.getName(), deparment);

        // -----------------------------//
        TableConfiguration account = new TableConfiguration();
        account.setName("AccountInfo");
        account.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + account.getName() + "DTOPB");
        account.setInsertParameterType(insertTypePrefix + account.getName() + "PB");
        account.setBaseResultMap(baseResult);
        account.setNamespace(packagePrefix + account.getName() + "Mapper");
        account.setUniqueColumn("accountId");
        account.setUpdateParameterType(account.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();
        column = new Column();
        column.setActualColumnName("accountType");
        column.setJavaProperty("accountType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.AccountTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("departmentId");
        column.setJavaProperty("department");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + deparment.getName() + "DTOPB");
        association.setSelect(packagePrefix + deparment.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("currency");
        column.setJavaProperty("currency");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurrencyEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("accountState");
        column.setJavaProperty("accountState");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.AccountStatusEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        account.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(account.getName(), account);


        // -----------------------------//
        TableConfiguration product = new TableConfiguration();
        product.setName("Product");
        product.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + product.getName() + "DTOPB");
        product.setInsertParameterType(insertTypePrefix + product.getName() + "PB");
        product.setBaseResultMap(baseResult);
        product.setNamespace(packagePrefix + product.getName() + "Mapper");
        product.setUniqueColumn("productId");
        product.setUpdateParameterType(product.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();
        column = new Column();
        column.setActualColumnName("productType");
        column.setJavaProperty("productType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.ProductTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("currency");
        column.setJavaProperty("currency");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurrencyEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("departmentId");
        column.setJavaProperty("department");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + deparment.getName() + "DTOPB");
        association.setSelect(packagePrefix + deparment.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("market");
        column.setJavaProperty("market");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.MarketEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("ulType");
        column.setJavaProperty("ulType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.UlTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("interestCalc");
        column.setJavaProperty("interestCalc");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.InterestCalcEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("liqLevel");
        column.setJavaProperty("liqLevel");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.LiqLevelEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        product.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(product.getName(), product);

        // -----------------------------------//
        TableConfiguration curve = new TableConfiguration();
        curve.setName("Curve");
        curve.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + curve.getName() + "DTOPB");
        curve.setInsertParameterType(insertTypePrefix + curve.getName() + "PB");
        curve.setBaseResultMap(baseResult);
        curve.setNamespace(packagePrefix + curve.getName() + "Mapper");
        curve.setUniqueColumn("curveId");
        curve.setUpdateParameterType(curve.getInsertParameterType());
        tableOverwrite.put(curve.getName(), curve);

        // -----------------------------//
        TableConfiguration productTrade = new TableConfiguration();
        productTrade.setName("ProductTrade");
        productTrade.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + productTrade.getName() + "DTOPB");
        productTrade.setInsertParameterType(insertTypePrefix + productTrade.getName() + "PB");
        productTrade.setBaseResultMap(baseResult);
        productTrade.setNamespace(packagePrefix + productTrade.getName() + "Mapper");
        productTrade.setUniqueColumn("tradeId");
        productTrade.setUpdateParameterType(productTrade.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();
        column = new Column();
        column.setActualColumnName("market");
        column.setJavaProperty("market");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.MarketEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("productType");
        column.setJavaProperty("productType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.ProductTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("departmentId");
        column.setJavaProperty("department");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + deparment.getName() + "DTOPB");
        association.setSelect(packagePrefix + deparment.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("currency");
        column.setJavaProperty("currency");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurrencyEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("tradeDirection");
        column.setJavaProperty("tradeDirection");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.TradeDirectionEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("interestType");
        column.setJavaProperty("interestType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurveTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("principleType");
        column.setJavaProperty("principleType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurveTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("initInAccountId");
        column.setJavaProperty("initInAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("initOutAccountId");
        column.setJavaProperty("initOutAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("initMidAccountId");
        column.setJavaProperty("initMidAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("returnInAccountId");
        column.setJavaProperty("returnInAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("returnOutAccountId");
        column.setJavaProperty("returnOutAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("returnMidAccountId");
        column.setJavaProperty("returnMidAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("ulType");
        column.setJavaProperty("ulType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.UlTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("interestCurveId");
        column.setJavaProperty("interestCurve");
        column.setResultType(ColumnResultType.COLLECTION);
        collection = new Collection();
        collection.setOfType(typePrefix + curve.getName() + "DTOPB");
        collection.setSelect(packagePrefix + curve.getName() + "Mapper.get");
        column.setCollection(collection);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("interestPaymentCurveId");
        column.setJavaProperty("interestPaymentCurve");
        column.setResultType(ColumnResultType.COLLECTION);
        collection = new Collection();
        collection.setOfType(typePrefix + curve.getName() + "DTOPB");
        collection.setSelect(packagePrefix + curve.getName() + "Mapper.get");
        column.setCollection(collection);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("interestCalc");
        column.setJavaProperty("interestCalc");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.InterestCalcEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("spreadType");
        column.setJavaProperty("spreadType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurveTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("spreadCurveId");
        column.setJavaProperty("spreadCurve");
        column.setResultType(ColumnResultType.COLLECTION);
        collection = new Collection();
        collection.setOfType(typePrefix + curve.getName() + "DTOPB");
        collection.setSelect(packagePrefix + curve.getName() + "Mapper.get");
        column.setCollection(collection);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("dividendType");
        column.setJavaProperty("dividendType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurveTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("dividendCurveId");
        column.setJavaProperty("dividendCurve");
        column.setResultType(ColumnResultType.COLLECTION);
        collection = new Collection();
        collection.setOfType(typePrefix + curve.getName() + "DTOPB");
        collection.setSelect(packagePrefix + curve.getName() + "Mapper.get");
        column.setCollection(collection);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("principleCurveId");
        column.setJavaProperty("principleCurve");
        column.setResultType(ColumnResultType.COLLECTION);
        collection = new Collection();
        collection.setOfType(typePrefix + curve.getName() + "DTOPB");
        collection.setSelect(packagePrefix + curve.getName() + "Mapper.get");
        column.setCollection(collection);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("liquidity");
        column.setJavaProperty("liquidity");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.LiqLevelEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        productTrade.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(productTrade.getName(), productTrade);

        // -----------------------------//
        TableConfiguration unrlsdCash = new TableConfiguration();
        unrlsdCash.setName("UnrlsdCashBasis");
        unrlsdCash.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + "CashDTOPB");
        unrlsdCash.setInsertParameterType(insertTypePrefix + "CashBasisPB");
        unrlsdCash.setBaseResultMap(baseResult);
        unrlsdCash.setNamespace(packagePrefix + unrlsdCash.getName() + "Mapper");
        unrlsdCash.setUniqueColumn("transactionId");
        unrlsdCash.setUpdateParameterType(unrlsdCash.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("cashState");
        column.setJavaProperty("cashState");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashStatusEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("currency");
        column.setJavaProperty("currency");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurrencyEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("source");
        column.setJavaProperty("source");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashSourceEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("sourceRevised");
        column.setJavaProperty("sourceRevised");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashSourceEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("tradeId");
        column.setJavaProperty("trade");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + productTrade.getName() + "DTOPB");
        association.setSelect(packagePrefix + productTrade.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("inAccountId");
        column.setJavaProperty("inAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("inAccountIdRevised");
        column.setJavaProperty("inAccountRevised");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("outAccountId");
        column.setJavaProperty("outAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("outAccountIdRevised");
        column.setJavaProperty("outAccountRevised");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("midAccountId");
        column.setJavaProperty("midAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("midAccountIdRevised");
        column.setJavaProperty("midAccountRevised");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("direction");
        column.setJavaProperty("direction");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.TradeDirectionEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        unrlsdCash.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(unrlsdCash.getName(), unrlsdCash);

        // -----------------------------//
        TableConfiguration unrlsdCashHist = new TableConfiguration();
        unrlsdCashHist.setName("UnrlsdCashBasisHist");
        unrlsdCashHist.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + "CashDTOPB");
        unrlsdCashHist.setInsertParameterType(insertTypePrefix + "CashBasisPB");
        unrlsdCashHist.setBaseResultMap(baseResult);
        unrlsdCashHist.setNamespace(packagePrefix + unrlsdCashHist.getName() + "Mapper");
        unrlsdCashHist.setUniqueColumn("transactionId");
        unrlsdCashHist.setUpdateParameterType(unrlsdCashHist.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("cashState");
        column.setJavaProperty("cashState");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashStatusEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("currency");
        column.setJavaProperty("currency");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurrencyEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("source");
        column.setJavaProperty("source");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashSourceEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("sourceRevised");
        column.setJavaProperty("sourceRevised");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashSourceEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("tradeId");
        column.setJavaProperty("trade");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + productTrade.getName() + "DTOPB");
        association.setSelect(packagePrefix + productTrade.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("inAccountId");
        column.setJavaProperty("inAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("inAccountIdRevised");
        column.setJavaProperty("inAccountRevised");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("outAccountId");
        column.setJavaProperty("outAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("outAccountIdRevised");
        column.setJavaProperty("outAccountRevised");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("midAccountId");
        column.setJavaProperty("midAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("midAccountIdRevised");
        column.setJavaProperty("midAccountRevised");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("direction");
        column.setJavaProperty("direction");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.TradeDirectionEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        unrlsdCashHist.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(unrlsdCashHist.getName(), unrlsdCashHist);

        // -----------------------------//
        TableConfiguration TransferRequest = new TableConfiguration();
        TransferRequest.setName("TransferRequest");
        TransferRequest.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + TransferRequest.getName() + "DTOPB");
        TransferRequest.setInsertParameterType(insertTypePrefix + TransferRequest.getName() + "PB");
        TransferRequest.setBaseResultMap(baseResult);
        TransferRequest.setNamespace(packagePrefix + TransferRequest.getName() + "Mapper");
        TransferRequest.setUniqueColumn("requestId");
        TransferRequest.setUpdateParameterType(TransferRequest.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("requestStatus");
        column.setJavaProperty("requestStatus");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.RequestStatusEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("inAccountId");
        column.setJavaProperty("inAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("outAccountId");
        column.setJavaProperty("outAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("midAccountId");
        column.setJavaProperty("midAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        TransferRequest.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(TransferRequest.getName(), TransferRequest);

        // -----------------------------//
        TableConfiguration autoTransferRequest = new TableConfiguration();
        autoTransferRequest.setName("AutoTransferRequest");
        autoTransferRequest.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + autoTransferRequest.getName() + "DTOPB");
        autoTransferRequest.setInsertParameterType(insertTypePrefix + autoTransferRequest.getName() + "PB");
        autoTransferRequest.setBaseResultMap(baseResult);
        autoTransferRequest.setNamespace(packagePrefix + autoTransferRequest.getName() + "Mapper");
        autoTransferRequest.setUniqueColumn("requestId");
        autoTransferRequest.setUpdateParameterType(autoTransferRequest.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("requestStatus");
        column.setJavaProperty("requestStatus");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.RequestStatusEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("inAccountId");
        column.setJavaProperty("inAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("outAccountId");
        column.setJavaProperty("outAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("midAccountId");
        column.setJavaProperty("midAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        autoTransferRequest.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(autoTransferRequest.getName(), autoTransferRequest);

        // -----------------------------//
        TableConfiguration RlsdCash = new TableConfiguration();
        RlsdCash.setName("RlsdCashBasis");
        RlsdCash.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + "CashDTOPB");
        RlsdCash.setInsertParameterType(insertTypePrefix + "CashBasisPB");
        RlsdCash.setBaseResultMap(baseResult);
        RlsdCash.setNamespace(packagePrefix + RlsdCash.getName() + "Mapper");
        RlsdCash.setUniqueColumn("transactionId");
        RlsdCash.setUpdateParameterType(RlsdCash.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("cashState");
        column.setJavaProperty("cashState");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashStatusEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("currency");
        column.setJavaProperty("currency");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurrencyEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("source");
        column.setJavaProperty("source");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashSourceEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("tradeId");
        column.setJavaProperty("trade");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + productTrade.getName() + "DTOPB");
        association.setSelect(packagePrefix + productTrade.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("inAccountId");
        column.setJavaProperty("inAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("outAccountId");
        column.setJavaProperty("outAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("midAccountId");
        column.setJavaProperty("midAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("direction");
        column.setJavaProperty("direction");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.TradeDirectionEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        RlsdCash.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(RlsdCash.getName(), RlsdCash);

        // -----------------------------//
        TableConfiguration RlsdCashHist = new TableConfiguration();
        RlsdCashHist.setName("RlsdCashBasisHist");
        RlsdCashHist.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + "CashDTOPB");
        RlsdCashHist.setInsertParameterType(insertTypePrefix + "CashBasisPB");
        RlsdCashHist.setBaseResultMap(baseResult);
        RlsdCashHist.setNamespace(packagePrefix + RlsdCashHist.getName() + "Mapper");
        RlsdCashHist.setUniqueColumn("transactionId");
        RlsdCashHist.setUpdateParameterType(RlsdCashHist.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("cashState");
        column.setJavaProperty("cashState");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashStatusEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("currency");
        column.setJavaProperty("currency");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CurrencyEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("source");
        column.setJavaProperty("source");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.CashSourceEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("tradeId");
        column.setJavaProperty("trade");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + productTrade.getName() + "DTOPB");
        association.setSelect(packagePrefix + productTrade.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("inAccountId");
        column.setJavaProperty("inAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("outAccountId");
        column.setJavaProperty("outAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("midAccountId");
        column.setJavaProperty("midAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("direction");
        column.setJavaProperty("direction");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.TradeDirectionEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        RlsdCashHist.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(RlsdCashHist.getName(), RlsdCashHist);

        // -----------------------------//
        TableConfiguration accountDeposit = new TableConfiguration();
        accountDeposit.setName("AccountDeposit");
        accountDeposit.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + accountDeposit.getName() + "DTOPB");
        accountDeposit.setInsertParameterType(insertTypePrefix + accountDeposit.getName() + "PB");
        accountDeposit.setBaseResultMap(baseResult);
        accountDeposit.setNamespace(packagePrefix + accountDeposit.getName() + "Mapper");
        accountDeposit.setUpdateParameterType(accountDeposit.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("accountId");
        column.setJavaProperty("account");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("transactionId");
        column.setJavaProperty("transaction");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(unrlsdCash.getBaseResultMap().getType());
        association.setSelect(packagePrefix + unrlsdCash.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        accountDeposit.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(accountDeposit.getName(), accountDeposit);

        // -----------------------------//
        TableConfiguration accountDepositHist = new TableConfiguration();
        accountDepositHist.setName("AccountDepositHist");
        accountDepositHist.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + accountDeposit.getName() + "DTOPB");
        accountDepositHist.setInsertParameterType(insertTypePrefix + accountDepositHist.getName() + "PB");
        accountDepositHist.setBaseResultMap(baseResult);
        accountDepositHist.setNamespace(packagePrefix + accountDepositHist.getName() + "Mapper");
        accountDepositHist.setUpdateParameterType(accountDepositHist.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("accountId");
        column.setJavaProperty("account");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("transactionId");
        column.setJavaProperty("transaction");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(unrlsdCash.getBaseResultMap().getType());
        association.setSelect(packagePrefix + unrlsdCash.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        accountDepositHist.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(accountDepositHist.getName(), accountDepositHist);

        // -----------------------------//
        TableConfiguration requestMapping = new TableConfiguration();
        requestMapping.setName("TransferRequestMapping");
        requestMapping.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(insertTypePrefix + requestMapping.getName() + "PB");
        requestMapping.setInsertParameterType(insertTypePrefix + requestMapping.getName() + "PB");
        requestMapping.setBaseResultMap(baseResult);
        requestMapping.setNamespace(packagePrefix + requestMapping.getName() + "Mapper");
        requestMapping.setUniqueColumn("requestId");
        requestMapping.setUpdateParameterType(requestMapping.getInsertParameterType());
        tableOverwrite.put(requestMapping.getName(), requestMapping);

        // -----------------------------//
        TableConfiguration requestAttachment = new TableConfiguration();
        requestAttachment.setName("TransferRequestAttachment");
        requestAttachment.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + requestAttachment.getName() + "DTOPB");
        requestAttachment.setInsertParameterType(insertTypePrefix + requestAttachment.getName() + "PB");
        requestAttachment.setBaseResultMap(baseResult);
        requestAttachment.setNamespace(packagePrefix + requestAttachment.getName() + "Mapper");
        requestAttachment.setUniqueColumn("requestId");
        requestAttachment.setUpdateParameterType(requestAttachment.getInsertParameterType());
        tableOverwrite.put(requestAttachment.getName(), requestAttachment);

        // -----------------------------//
        TableConfiguration transferRule = new TableConfiguration();
        transferRule.setName("CashTransferRule");
        transferRule.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + transferRule.getName() + "DTOPB");
        transferRule.setInsertParameterType(insertTypePrefix + transferRule.getName() + "PB");
        transferRule.setBaseResultMap(baseResult);
        transferRule.setNamespace(packagePrefix + transferRule.getName() + "Mapper");
        transferRule.setUniqueColumn("ruleId");
        transferRule.setUpdateParameterType(transferRule.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("productType");
        column.setJavaProperty("productType");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.ProductTypeEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("departmentId");
        column.setJavaProperty("department");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + deparment.getName() + "DTOPB");
        association.setSelect(packagePrefix + deparment.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);
        
        column = new Column();
        column.setActualColumnName("initInAccountId");
        column.setJavaProperty("initInAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("initOutAccountId");
        column.setJavaProperty("initOutAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("initMidAccountId");
        column.setJavaProperty("initMidAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("initDirection");
        column.setJavaProperty("initDirection");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.TradeDirectionEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);
        
        column = new Column();
        column.setActualColumnName("returnInAccountId");
        column.setJavaProperty("returnInAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("returnOutAccountId");
        column.setJavaProperty("returnOutAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("returnMidAccountId");
        column.setJavaProperty("returnMidAccount");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + account.getName() + "DTOPB");
        association.setSelect(packagePrefix + account.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);

        column = new Column();
        column.setActualColumnName("returnDirection");
        column.setJavaProperty("returnDirection");
        column.setResultType(ColumnResultType.RESULT);
        jdbcType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.INTEGER));
        jdbcType.setTypeHandler("com.orientsec.cashmgmt.handler.TradeDirectionEnumTypeHandler");
        column.setTypeInfo(jdbcType);
        columnOverWrite.put(column.getActualColumnName(), column);

        transferRule.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(transferRule.getName(), transferRule);

        // -----------------------------//
        TableConfiguration audit = new TableConfiguration();
        audit.setName("Audit");
        audit.setBaseColumnListId("baseColumnList");
        baseResult = new ResultMap();
        baseResult.setId("baseResultMap");
        baseResult.setType(typePrefix + audit.getName() + "DTOPB");
        audit.setInsertParameterType(insertTypePrefix + audit.getName() + "PB");
        audit.setBaseResultMap(baseResult);
        audit.setNamespace(packagePrefix + audit.getName() + "Mapper");
        audit.setUniqueColumn("auditId");
        audit.setUpdateParameterType(audit.getInsertParameterType());

        columnOverWrite = new HashMap<String, Column>();

        column = new Column();
        column.setActualColumnName("departmentId");
        column.setJavaProperty("department");
        column.setResultType(ColumnResultType.ASSOCIATION);
        association = new Association();
        association.setJavaType(typePrefix + deparment.getName() + "DTOPB");
        association.setSelect(packagePrefix + deparment.getName() + "Mapper.get");
        column.setAssociation(association);
        column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(Types.VARCHAR));
        columnOverWrite.put(column.getActualColumnName(), column);
        
        audit.setColumnOverWrite(columnOverWrite);
        tableOverwrite.put(audit.getName(), audit);

        return tableOverwrite;
    }

    private static Map<Integer, JDBCType> configTypeOverwrite() {
        Map<Integer, JDBCType> jdbcTypeOverwrite = new HashMap<Integer, JDBCType>();

        JDBCType decimalType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.DECIMAL));
        decimalType.setJavaType(Double.class.getName());
        jdbcTypeOverwrite.put(Types.DECIMAL, decimalType);

        JDBCType timestampType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.TIMESTAMP));
        timestampType.setTypeHandler("com.orientsec.cashmgmt.handler.CustomSqlDateTypeHandler");
        jdbcTypeOverwrite.put(Types.TIMESTAMP, timestampType);

        JDBCType bitType = cloneJDBCType(BaseJDBCTypeMapping.getJdbcType(Types.BIT));
        bitType.setTypeHandler("com.orientsec.cashmgmt.handler.BitBooleanTypeHandler");
        jdbcTypeOverwrite.put(Types.BIT, bitType);

        return jdbcTypeOverwrite;
    }

    private static JDBCType cloneJDBCType(JDBCType jdbcType) {
        JDBCType _jdbcType = new JDBCType();
        _jdbcType.setJavaType(jdbcType.getJavaType());
        _jdbcType.setName(jdbcType.getName());
        _jdbcType.setType(jdbcType.getType());
        _jdbcType.setTypeHandler(jdbcType.getTypeHandler());

        return _jdbcType;
    }
}
