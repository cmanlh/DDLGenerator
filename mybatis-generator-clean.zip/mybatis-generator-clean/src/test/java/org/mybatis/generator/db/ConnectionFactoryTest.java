package org.mybatis.generator.db;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;
import org.mybatis.generator.db.bean.JDBCConnectionConfiguration;
import org.mybatis.generator.db.constant.BaseJDBCTypeMapping;
import org.mybatis.generator.db.constant.DatabaseUserTable;
import org.mybatis.generator.db.util.DBInfoUtil;

public class ConnectionFactoryTest {

    @Test
    public void connection() {
        JDBCConnectionConfiguration config = new JDBCConnectionConfiguration();
        config.setConnectionURL("jdbc:jtds:sqlserver://172.16.45.87;DatabaseName=CashMgmt");
        config.setDriverClass("net.sourceforge.jtds.jdbc.Driver");
        config.setUserId("devuser");
        config.setPassword("test@1234");

        ConnectionFactory connectionFactory = ConnectionFactory.getInstance();
        try {
            Connection connection = connectionFactory.getConnection(config);
            PreparedStatement pps =
                    connection
                            .prepareStatement(DatabaseUserTable.getDatabaseUserTable(DBInfoUtil.getDBType(config)).getUserTableRetrievalStatement());
            ResultSet rs = pps.executeQuery();

            while (rs.next()) {
                System.out.println(rs.getString(1));
            }

            ResultSet columnRS = connection.getMetaData().getColumns(connection.getCatalog(), null, "Product", null);
            while (columnRS.next()) {
                System.out.println(BaseJDBCTypeMapping.getJdbcType(columnRS.getInt("DATA_TYPE")).getName() + " "
                        + BaseJDBCTypeMapping.getJdbcType(columnRS.getInt("DATA_TYPE")).getJavaType() + " " + columnRS.getInt("COLUMN_SIZE") + " "
                        + columnRS.getString("COLUMN_NAME") + " " + (columnRS.getInt("NULLABLE") == DatabaseMetaData.columnNullable) + " "
                        + columnRS.getInt("DECIMAL_DIGITS") + " " + columnRS.getString("REMARKS") + " " + columnRS.getString("COLUMN_DEF"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void connection2() {
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:jtds:sqlserver://172.16.45.87;DatabaseName=CashMgmt", "devuser", "test@1234");

            JDBCConnectionConfiguration config = new JDBCConnectionConfiguration();
            config.setConnectionURL("jdbc:jtds:sqlserver://172.16.45.87;DatabaseName=CashMgmt");
            config.setDriverClass("net.sourceforge.jtds.jdbc.Driver");
            config.setUserId("devuser");
            config.setPassword("test@1234");

            PreparedStatement pps =
                    con.prepareStatement(DatabaseUserTable.getDatabaseUserTable(DBInfoUtil.getDBType(config)).getUserTableRetrievalStatement());
            ResultSet tableRS = pps.executeQuery();

            while (tableRS.next()) {
                ResultSet columnRS = con.getMetaData().getColumns(con.getCatalog(), null, tableRS.getString(1), null);
                ResultSet rs = con.getMetaData().getPrimaryKeys(con.getCatalog(), null, tableRS.getString(1));
                ResultSet rs2 = con.getMetaData().getBestRowIdentifier(con.getCatalog(), null, tableRS.getString(1), 0, true);

                while (rs.next()) {
                    System.out.println(rs.getString("COLUMN_NAME"));
                }
                System.out.println("---------------------");
                while (rs2.next()) {
                    System.out.println(rs2.getString("COLUMN_NAME"));
                }

                while (columnRS.next()) {

                    System.out.println(BaseJDBCTypeMapping.getJdbcType(columnRS.getInt("DATA_TYPE")).getName() + " "
                            + BaseJDBCTypeMapping.getJdbcType(columnRS.getInt("DATA_TYPE")).getJavaType() + " " + columnRS.getInt("COLUMN_SIZE")
                            + " " + columnRS.getString("COLUMN_NAME") + " " + (columnRS.getInt("NULLABLE") == DatabaseMetaData.columnNullable) + " "
                            + columnRS.getInt("DECIMAL_DIGITS") + " " + columnRS.getString("REMARKS") + " " + columnRS.getString("COLUMN_DEF"));
                }
            }
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
