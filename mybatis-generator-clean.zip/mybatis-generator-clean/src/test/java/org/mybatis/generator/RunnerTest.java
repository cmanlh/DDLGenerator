/**
 * 
 */
package org.mybatis.generator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mybatis.generator.bean.GlobalConfiguration;
import org.mybatis.generator.bean.TableConfiguration;
import org.mybatis.generator.codegen.dao.DAOGenerator;
import org.mybatis.generator.codegen.model.PBDefinitionGenerator;
import org.mybatis.generator.codegen.xml.TableElementGenerator;
import org.mybatis.generator.codegen.xml.bean.ResultMap;
import org.mybatis.generator.codegen.xml.impl.BaseColumnListElementGenerator;
import org.mybatis.generator.codegen.xml.impl.BaseResultMapElementGenerator;
import org.mybatis.generator.codegen.xml.impl.DeleteElementGenerator;
import org.mybatis.generator.codegen.xml.impl.InsertFullElementGenerator;
import org.mybatis.generator.codegen.xml.impl.RootElementGenerator;
import org.mybatis.generator.codegen.xml.impl.SQLDynamicUpdateElementGenerator;
import org.mybatis.generator.codegen.xml.impl.SQLUpdateElementGenerator;
import org.mybatis.generator.codegen.xml.impl.SelectGetElementGenerator;
import org.mybatis.generator.codegen.xml.impl.UpdateFullElementGenerator;
import org.mybatis.generator.codegen.xml.impl.XMLMapperGenerator;
import org.mybatis.generator.db.ConnectionFactory;
import org.mybatis.generator.db.bean.Column;
import org.mybatis.generator.db.bean.JDBCConnectionConfiguration;
import org.mybatis.generator.db.bean.JDBCType;
import org.mybatis.generator.db.bean.Table;
import org.mybatis.generator.db.constant.BaseJDBCTypeMapping;
import org.mybatis.generator.db.constant.ColumnResultType;
import org.mybatis.generator.db.constant.DatabaseUserTable;
import org.mybatis.generator.db.util.DBInfoUtil;

/**
 * @author luhong
 *
 */
public class RunnerTest {


    @Test
    public void connection() {
        JDBCConnectionConfiguration config = new JDBCConnectionConfiguration();
        config.setConnectionURL("jdbc:jtds:sqlserver://172.16.45.87;DatabaseName=CashMgmt");
        config.setDriverClass("net.sourceforge.jtds.jdbc.Driver");
        config.setUserId("devuser");
        config.setPassword("test@1234");

        ConnectionFactory connectionFactory = ConnectionFactory.getInstance();
        try {
            Connection connection = connectionFactory.getConnection(config);
            PreparedStatement pps =
                    connection
                            .prepareStatement(DatabaseUserTable.getDatabaseUserTable(DBInfoUtil.getDBType(config)).getUserTableRetrievalStatement());
            ResultSet rs = pps.executeQuery();

            GlobalConfiguration globalConfiguration = MakeConfiguration.get();

            while (rs.next()) {
                String tablename = rs.getString(1);
                ResultSet columnRS = connection.getMetaData().getColumns(connection.getCatalog(), null, tablename, null);

                TableConfiguration tableConfig = globalConfiguration.getTableOverwrite().get(tablename);

                Table table = new Table();
                if (null == tableConfig) {
                    table.setBaseColumnListId("baseColumnList");
                    ResultMap resultMap = new ResultMap();
                    resultMap.setId("baseResultMap");
                    resultMap.setType("com.Test$Hello");
                    table.setBaseResultMap(resultMap);
                    table.setInsertParameterType("com.Test");
                    table.setName(tablename);
                    table.setNamespace("com");
                    table.setUpdateParameterType("com.Test");
                } else {
                    table.setBaseColumnListId(tableConfig.getBaseColumnListId());
                    table.setBaseResultMap(tableConfig.getBaseResultMap());
                    table.setInsertParameterType(tableConfig.getInsertParameterType());
                    table.setName(tablename);
                    table.setNamespace(tableConfig.getNamespace());
                    table.setUpdateParameterType(tableConfig.getUpdateParameterType());
                    if (tableConfig.getUniqueColumn() != null && tableConfig.getUniqueColumn().length() > 0) {
                        Column column = new Column();
                        column.setActualColumnName(tableConfig.getUniqueColumn());
                        table.setUniqueKey(column);
                    }
                }


                List<Column> columnList = new ArrayList<Column>();
                while (columnRS.next()) {
                    Column column = null;
                    String columnName = columnRS.getString("COLUMN_NAME");
                    if (null != tableConfig && null != tableConfig.getColumnOverWrite()) {
                        column = tableConfig.getColumnOverWrite().get(columnName);
                    }

                    if (null == column) {
                        column = new Column();
                        column.setActualColumnName(columnName);
                        column.setJavaProperty(columnName);
                        column.setResultType(ColumnResultType.RESULT);
                        column.setNullable(columnRS.getInt("NULLABLE") == DatabaseMetaData.columnNullable);

                        int dataType = columnRS.getInt("DATA_TYPE");
                        JDBCType overwriteType = globalConfiguration.getJdbcTypeOverwrite().get(dataType);
                        if (null != overwriteType) {
                            column.setTypeInfo(overwriteType);
                        } else {
                            column.setTypeInfo(BaseJDBCTypeMapping.getJdbcType(dataType));
                        }
                    }

                    columnList.add(column);
                }
                table.setColumnList(columnList);

                List<TableElementGenerator> elementGeneratorList = new ArrayList<TableElementGenerator>();

                elementGeneratorList.add(new RootElementGenerator());
                elementGeneratorList.add(new BaseResultMapElementGenerator());
                elementGeneratorList.add(new BaseColumnListElementGenerator());
                if (null != table.getUniqueKey()) {
                    elementGeneratorList.add(new SelectGetElementGenerator());
                }
                elementGeneratorList.add(new InsertFullElementGenerator());
                elementGeneratorList.add(new SQLUpdateElementGenerator());
                if (null != table.getUniqueKey()) {
                    elementGeneratorList.add(new UpdateFullElementGenerator());
                }
                elementGeneratorList.add(new SQLDynamicUpdateElementGenerator());
                if (null != table.getUniqueKey()) {
                    elementGeneratorList.add(new DeleteElementGenerator());
                }
                XMLMapperGenerator xmlMapperGenerator = new XMLMapperGenerator(table, elementGeneratorList);
                try {
                    File file = new File(globalConfiguration.getXmlMapperFolder() + table.getName() + "Mapper.xml");
                    FileOutputStream fos = new FileOutputStream(file);
                    fos.write(xmlMapperGenerator.getDocument().getFormattedContent().getBytes("UTF-8"));
                    fos.close();

                    File daoFile = new File(globalConfiguration.getDaoFolder() + table.getName() + "Mapper.java");
                    FileOutputStream daoFos = new FileOutputStream(daoFile);
                    daoFos.write(new DAOGenerator().getContent(table).getBytes("UTF-8"));
                    daoFos.close();

                    PBDefinitionGenerator pbDefinitionGenerator =
                            new PBDefinitionGenerator("com.orientsec.cashmgmt.pb", new ArrayList<String>(), new ArrayList<String>());
                    System.out.println(pbDefinitionGenerator.getContent(table));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
